## SoftDes MP4:

# STARFIGHTER 

Nathan Weil, Maya Al-Ahmad 2019

In STARFIGHTER, the player controls a ship that appears at the bottom
of the screen. The player can rotate the ship to the left or right and use 
the ships thrusters to move forward by pressing the arrow keys. Pressing 
the space bar results in the ship shooting phasers. When the game begins, 
a enemy starfighters begin to appear in random locations and move around 
the screen. The goal of the game is to survive as long as possible! Once 
you lose three ships by collision with enemy starfighters, the game ends. 

Good luck and happy phasing!

Note:
The game is derived from the classic arcade game, ASTEROIDS. 
